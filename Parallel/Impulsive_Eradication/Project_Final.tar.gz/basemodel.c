#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h> 
#include<malloc.h>
#include "functions.h"

const int MAX_THREADS = 10; 
long long gen = 0; 
long long rows;
long long **current;
long long **temp;
long long columns;

int main(void) {
   int i = 0;
   long thread;
   size = 10;
   thread_count = 10;
   pthread_t * thread_handles;
   pthread_t * thread_trans;
   pthread_t * thread_temptocurr;
   columns = 10;
   rows = 10;
   
   current = (long long ** ) malloc((rows+1) * sizeof(*current)); // Allocating memory to 2D array current; 
   temp = (long long ** ) malloc((columns+1) * sizeof(*temp)); // Allocating memory to 2D array temp;

   for (i = 0; i < columns; i++) {
      current[i] = (long long * ) malloc((rows + 1) * sizeof(current));
      temp[i] = (long long * ) malloc((columns +1) * sizeof(current));
   }

   thread_handles = malloc(thread_count * (sizeof(pthread_t)));
   thread_temptocurr = malloc(thread_count *( sizeof(pthread_t)));
   thread_trans = malloc(thread_count *( sizeof(pthread_t)));
   //free(thread_handles);

   //Create the child thread and pass the child thread rank "thread" 
   // to the child_hello() function
   for (thread = 0; thread < thread_count; thread++)
      pthread_create( & thread_handles[thread], NULL, fillFirstGen, (void * ) thread);

   for (thread = 0; thread < thread_count; thread++)
      pthread_join(thread_handles[thread], NULL);
   free(thread_handles);   
   display();
      free(thread_temptocurr);
      free(thread_trans);
   for (i = 0 ; i < 100; i++){
    sleep(1);
   for (thread = 0; thread < thread_count; thread++)
      pthread_create( & thread_trans[thread], NULL, transisition, (void * ) thread);
    for (thread = 0; thread < thread_count; thread++)
         pthread_join(thread_trans[thread], NULL);
    for (thread = 0; thread < thread_count; thread++)
          pthread_create( & thread_temptocurr[thread], NULL, temptocurr, (void * ) thread);
     for (thread = 0; thread < thread_count; thread++)
     pthread_join(thread_temptocurr[thread], NULL);
     printf("\nCurrent Matrix\n");
       display();
       //free(thread_temptocurr);
      //free(thread_trans);
   }
   
//}
      
     
//   for (thread = 0; thread < thread_count; thread++)
  //    pthread_create( & thread_handles[thread], NULL, temptocurr, (void * ) thread);

//   for (thread = 0; thread < thread_count; thread++)
  //    pthread_join(thread_handles[thread], NULL);
    
  // for (i = 0; i < 3; i++){
 /*   for (thread = 0; thread < thread_count; thread++)
      pthread_create( & thread_handles[thread], NULL, transisition, (void * ) thread);

   for (thread = 0; thread < thread_count; thread++)
      pthread_join(thread_handles[thread], NULL);

   free(thread_handles);

   printf("\n");
   printf("\nCurrent Matrix\n");
   //printf("\nCurrent Block");
   for (thread = 0; thread < thread_count; thread++)
      pthread_create( & thread_handles[thread], NULL, temptocurr, (void * ) thread);

   for (thread = 0; thread < thread_count; thread++)
      pthread_join(thread_handles[thread], NULL);
    display();
   free(thread_handles);
  // }*/

   free(current);
   free(temp);
   // printf("\nTemp Block");
   //  show(Temp);
   printf("\n");
   
}
